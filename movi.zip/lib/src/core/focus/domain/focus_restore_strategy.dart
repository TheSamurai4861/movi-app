enum FocusRestoreStrategy { restoreLastFocused, primaryOnly }
