bool isWindowsWebHost() => false;
