enum FocusRestoreStrategy { restoreLastFocused, primaryOnly }
