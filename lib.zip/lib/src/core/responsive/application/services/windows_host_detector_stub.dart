bool isWindowsWebHost() => false;
