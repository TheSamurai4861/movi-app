// Public barrel for local persistence services and repositories.
//
// This entry-point exposes the repositories backed by SQLite / secure storage,
// plus the cache policy and storage failures used by higher layers.
export 'repositories/iptv_local_repository.dart';
export 'repositories/content_cache_repository.dart';
export 'repositories/secure_payload_store.dart';
export 'repositories/secure_storage_repository.dart';
export 'repositories/playlist_local_repository.dart';
export 'repositories/watchlist_local_repository.dart';
export 'repositories/continue_watching_local_repository.dart';
export 'repositories/history_local_repository.dart';
export 'repositories/playback_variant_selection_local_repository.dart';
export 'repositories/series_seen_state_repository.dart';
export 'repositories/sync_outbox_repository.dart';
export 'services/cache_policy.dart';
export 'storage_failures.dart';
